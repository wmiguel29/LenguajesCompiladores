from tkinter.constants import FALSE
from tabulate import tabulate  # Facilita la tabulación de los datos
# Integrado para facilitar el uso del programa en consola. Lee la tecla que el usuario oprima de forma inmediata.
import readchar as rc
import tkinter as tk  # Integrado para la interfaz de selección de archivo
from tkinter import filedialog as fd
from glc_arithmetic import EndHandler, glc


# Implementa la tabla de signos como diccionario de python
def tblToDic(file_name) -> dict:
    csv = open(file_name, "r")  # Abre el archivo con la tabla
    # Guarda una lista con cada fila de la tabla. En el archivo cada una está separada por una coma y un \n
    rows = csv.read().split(",\n")
    csv.close()  # Cierra el archivo
    # Split rows into columns
    table = {}
    for row in rows[1:]:  # Lee las filas desde la segunda fila. La primera se ignora porque indicar el formato de la tabla
        # Separa las filas por columnas. En la tabla están separadas por '||'
        row = row.split("||")
        # El signo, que se encuentra en la fila 0 (row[0]), será el índice; y sus tipos los objetos
        table[row[0]] = row[1:]
    return table

# Toma los símbolos que son separadores de la tabla ya implementada como diccionario


def getDelimiters(table: dict) -> list:
    delimiters = []
    for i in table:
        # Recorre cada índice de la tabla y busca si contiene el tipo separador
        if "delimiter" in table[i]:
            delimiters.append(i)
    return delimiters

# Carga el código fuente como cadena. En caso de que no exista el archivo, lo indica.


def loadCode(source_dir: str) -> str:
    try:
        with open(source_dir, "r") as code:  # El archivo se abre como 'solo lectura'
            code = code.read()
        return code
    except:
        print("No file selected")
        print("Press any key to exit")
        k = rc.readchar()
        exit()


'''
TALLER 1:

Se analiza un archivo con código para encontrar símbolos significativos en un lenguaje de programación. 
Dicho lenguaje es arbitrario y sus símbolos están definidos en un archivo dentro de la carpeta del proyecto, 
con un formato específico de tabla.
El archivo de código se selecciona mediante una interfaz de búsqueda de archivos.
El programa carga y procesa la tabla como diccionario de python, carga el archivo de código como una cadena de texto y 
luego procede a recorrer dicha cadena caracter por caracter, acumulandolos hasta encontrar un separador. Al encontrar 
un separador, se clasifica la cadena acumulada hasta el momento según el diccionario con la tabla de símbolos. Una vez
hecha la clasificación, se reaunda el proceso de acumulación de caracteres con el acumulador vacío; así hasta haber 
recorrido todo el texto.
Finalmente, los símbolos identificados se muestran en pantalla como tabla
'''

# El archivo con la tabla se llama "symbol_table.tb"¨. En esta linea asigna el diccionario a 's_table'
s_table = tblToDic("symbol_table.tb")
# Toma los símbolos del diccionario y los alacena en una lista
symbols = list(s_table.keys())
# char(3) = ETX. Se usa como aracter de control para que el algoritmo lea la última palabra
delimiters = getDelimiters(s_table) + [chr(3)]

#Inicio
print("Binevenido al Compilador \nPresione 0 para salir, cualquier otra tecla para seleccionar archivo")
k = rc.readchar()
if k == "0":
    quit()
root = tk.Tk()
root.withdraw()
file_name = fd.askopenfilename()
code = loadCode(file_name)  # Carga el código duente
# Control character at end of code. Avoids data loss and simplifies code
code += chr(3)

# Variable con la tabla del resultado del analisis
f_table = [["symbol", "type1", "type2", "type3", "line", "column"]]

word = ""  # Acumulador de caracteres del código
line = 1  # Control de la linea que se analiza
col = 1  # Control de la columna que se analiza

# Llenado de la tabla final
for i in code:
    if i in delimiters:
        # Condicionales para clasificar las palabras
        if word in symbols:
            # En caso de que la palabra se encuentre entre los símbolos definidos
            f_table.append([repr(word)] + s_table[word] +
                           [line, (col - len(word))])
        elif word != "":
            # Si no se encuentra la palabra, se clasifica como identificador
            f_table.append([repr(word), "identifier", "",
                           "", line, (col - len(word))])
        if i != chr(3):
            # Añade la ubicación del separador
            f_table.append([repr(i)] + s_table[i] + [line, col])
        word = ""  # Vacía el acumulador
    # Location Control
    if i != "\n":
        if i not in delimiters:  # In case of adjacent delimiters
            word += i  # Acumula el caracter
        col += 1  # Suma 1 a la columna si el carater analizado no es un 'new line'
    else:
        line += 1  # Suma 1 a la fila si el carater analizado es un 'new line'
        col = 1  # Y lleva la columna nuevamente a 0

'''
TALLER 2

1. Tabla de tokens:
Se analiza el mismo archivo de código, tal como en el taller anterior, para reconocer si existen símbolos de los que 
pueda decirse que son lexemas correspondientes a tokens definidos en un nuevo archivo con un formato especifico de
tabla. 
La cadena con el código se recorre nuevamente, usando el mismo algoritmo del taller 1, esta vez según la definición
de la tabla de tokens, para finalmente mostrar en pantalla todos los tokens encontrados organizados en una tabla.
'''

# Almacena la tabla con la definición de los tokens en un diccioniario
tkn_table = tblToDic("tokens.tb")
# Extrae lexemas del diccionario y los alamcena por separado en una lista
lexemes = list(tkn_table.keys())
word = ""  # Acumulador de caracteres del código
f_table2 = [["token", "id", "lexeme"]]  # Definición de la tabla final
for i in code:  # Llenado de la tabla de tokens
    if i in delimiters:  # Condicional de si encuentra un separador
        # Análisis de la palabra acumulada:
        if word in lexemes:  # Condicional si se identidfica un lexema
            # En caso de que la palabra se encuentre entre los tokens definidos
            # Añade el token a la tabla
            f_table2.append(tkn_table[word] + [repr(word)])
        elif word != "":
            # Si no se encuentra el token, se clasifica como identificador
            f_table2.append(["identifier", 17, repr(word)])
        if i != chr(3):
            # Añade la ubicación de token separador
            f_table2.append(tkn_table[i] + [repr(i)])
        word = ""  # Vacía el acumulador
    if i != "\n":
        if i not in delimiters:  # Linea que controla el caso en el que hay 2 separadores seguidos
            word += i  # Acumula el caracter

'''
2. Identifiación de expresiones aritméticas:
Se requiere que el programa identifique posibles expresiones aritméticas dentro del código, las localice y las
almacene en una estructura separada.
Con ese propósito, el programa recorrerá la tabla de signos, ignorando espacios, en busca de los componentes de una
operación aritmética que según las definiciones del lenguaje actual son identificadores y operadores aritméticos,
aunque será semcillo añadir paréntesis o números en caso de ser necesario posteriormente.
El algoritmo empleado acumula las secuencias compuestas por operadores aritméticos o identificadores y acumula
aquellas cuyo tamaño es de 3 o más caracteres. 
El algoritmo también considera la localización de la expresión, tomando de la tabla de símbolos la localización
del primero de los símbolos que la conforman.
'''
f_table.append(["end of table", "", "", "", "", ""]
               )  # Fila de control que indicará al programa cuando terminar de buscar operaciones
# Definición de tabla de operaciones aritméticas
arit_ops = [["expression", "location"]]
arit_op = ""  # Acumulador que almacena la expresión aritmética
size = 0  # Control de tamaño de la expresión
location = []  # Control de localización de la expresión
was_ident = False #Control para que no se acepten dos identificadores seguidos

for row in f_table:
    if row[0] != "' '":  # Ignora los espacios en la tabla de símbolos
        # Condicional si se encuentra un identificador o un operadot
        if ("identifier" in row and not was_ident) or "arithmetic operator" in row:
            arit_op += row[0] + " "  # Acumula el símbolo en la expresión
            if size == 0:
                # Añade la ocalización de la expresion en caso de estar analizando su primer símbolo
                location = [row[4], row[5]]
            size += 1  # Control tamaño de la expresión
            was_ident = True if "identifier" in row else False
        else:
            if size > 2:  # Filtra las expresiones cuyo tamaño es mayor que 1
                # Agrega la expresión a la tabla
                arit_ops.append([arit_op.replace("'", ""), location])
            size = 0  # Reinicia el contador de tamaño para una nueva expresión
            arit_op = ""  # Reinicia el acumulador de expresión para la siguiente
            was_ident = False

del f_table[-1]  # Elimina la fila de control en la tabla de símbolos

raw_ops = []
for exp in arit_ops[1:]:
    raw_ops.append(exp[0].replace(" ", ""))

# Menú
ctrl = 1
while ctrl == 1:
    print(
        "MENÚ: \n\n"
        "0. Salir \n"
        "1. Imprimir Tabla de Símbolos \n"
        "2. Imprimir Tabla de Tokens \n"
        "3. Análisis de expresiones aritméticas\n"
    )
    selection = input("Seleccione >>>")
    if selection == "0":
        ctrl = 0
    if selection == "1":
        print("Tabla de símbolos\n" + tabulate(f_table, headers='firstrow', tablefmt='fancy_grid') + '\n\n')
    if selection == "2":
        print("Tabla de tokens\n" + tabulate(f_table2, headers='firstrow', tablefmt='fancy_grid') + '\n\n')
    if selection == "3":
        print("Expresiones aritméticas\n" + tabulate(arit_ops, headers='firstrow', tablefmt='fancy_grid') + '\n\n')
        ctrl1 = 1
        while(ctrl1 == 1):
            print("Seleccione expresión para analizar")
            print("0. Volver")
            for i, exp in enumerate(raw_ops):
                print(str(i + 1) + ". " + exp)
            print()
            i = input("Seleccione >>>")
            if i != "0":
                art_glc = glc(raw_ops[int(i) - 1])
                try:
                    art_glc.main()
                except EndHandler:
                    pass
            else:
                ctrl1 = 0
            print("\n")
""" print("lexical analysis from " + "'{}'".format(file_name) + '\n\n')
print("SYMBOL TABLE\n" + tabulate(f_table,
      headers='firstrow', tablefmt='fancy_grid') + '\n\n')
print("TOKEN TABLE\n" + tabulate(f_table2,
      headers='firstrow', tablefmt='fancy_grid') + '\n\n')
print("ARITHMETIC EXPRESSION\n" + tabulate(arit_ops,
      headers='firstrow', tablefmt='fancy_grid') + '\n\n')
print("press any key to exit")
k = rc.readchar() """
