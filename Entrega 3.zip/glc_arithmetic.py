"""
TALLER 3

Programación de la gramática libre de contexto.
Se tomó la gramática planteada en el parcial, se le eliminó la recursividad a la izquierda y se codificó tal y
como se indicó en las ruta de aprendizaje correspondiente vista en clase. Particularmente, se implementó por
medio de una clase llamada glc, que es importada por el programa principal "compiler.py". Como atributos de
esta clase se asignan la cinta de entrada (variable "operation"), la posición de la cinta en la que va el
análisis ("position"), y el token de entrada ("tokenEntrada). Como métodos de la clase están las funciones
auxiliares para el análisis de la cinta y los correspondientes a los símbolos no terminales de la gramática.
"""

#Para administrar la salida de la función principal en "compiler.py"
class EndHandler(Exception):
    pass

#Implamentación de la gramática
class glc:

    def __init__(self, operation: str) -> None:
        self.operation = operation
        self.position = 0
        self.tokenEntrada = 0
        self.valid = False

    #Funciones auxiliares
    def main(self):
        self.position = 0
        self.tokenEntrada = self.firstToken()
        self.expr()
    
    def end(self):
        if self.tokenEntrada.isalnum() or self.tokenEntrada == ")":
            print("Cadena Aceptada")
            self.valid = True
        else:
            print("Error detectado, falta un valor o un identificador al final de la expresión")
        raise EndHandler
    
    def firstToken(self):
        self.position += 1
        return self.operation[0]
    
    def nextToken(self):
        self.position += 1
        if self.position <= len(self.operation):
            return self.operation[self.position - 1] 
        else: 
           self.end()

    def doMatch(self, t: str):
        if t == self.tokenEntrada:
            print("analizando caracter: " + self.tokenEntrada)
            self.tokenEntrada = self.nextToken()
        else:
            print("Error detectado")
            raise EndHandler
    
    #Funciones de estados no terminales:
    def expr(self):
        self.term()
        self.expr_prime()

    def term(self):
        self.fact()
        self.term_prime()
    
    def fact(self):
        if self.tokenEntrada == "(":
            self.doMatch(self.tokenEntrada)
            self.expr()
            if self.tokenEntrada == ")":
                self.doMatch(self.tokenEntrada)
        elif self.tokenEntrada.isnumeric():
            self.nums()
        elif self.tokenEntrada.isalpha():
            self.ident()
        else:
            print("Error detectado, falta factor o está incompleto")
            raise EndHandler
    
    def nums(self):
        self.digt()
        self.nums_prime()
    
    def ident(self):
        self.letter()
        self.ident_prime()

    def digt(self):
        if self.tokenEntrada.isnumeric():
            self.doMatch(self.tokenEntrada)
        else:
            print("Error detectado, se esperaba un dígito")
            raise EndHandler
    
    def letter(self):
        if self.tokenEntrada.isalpha():
            self.doMatch(self.tokenEntrada)
        else:
            print("Error detectado, se esperaba una letra")
            raise EndHandler

    def expr_prime(self):
        if self.tokenEntrada == "+" or self.tokenEntrada == "-":
            self.doMatch(self.tokenEntrada)
            self.term()
            self.expr_prime()
        else:
            pass 
    
    def term_prime(self):
        if self.tokenEntrada == "*" or self.tokenEntrada == "/":
            self.doMatch(self.tokenEntrada)
            self.fact()
            self.term_prime()
        else:
            pass
    
    def nums_prime(self):
        if self.tokenEntrada.isnumeric():
            self.digt()
            self.nums_prime()
        else:
            pass
    
    def ident_prime(self):
        if self.tokenEntrada.isalpha():
            self.letter()
            self.ident_prime()
        else:
            pass
    
""" 
#Código de prueba:

operation = "u*u-(a+a*a)"
test_glc = glc(operation)
test_glc.main()
print("Cadena aceptada")
print("end")
 """
